Requirement: ReShade/any other custom shader is installed

Once time experience:
1. Extract DXShader outside game directory
2. Open app and copy-paste path of game executable directory (not launcher)
3. Done

Common usage:
Open app, dont close the app, done

Game switching:
Open 'DXShader.dat' using notepad or other text editor.
Change number based on value below.
Save.
Open app.

DXShader.dat:
0 = Genshin Impact
1 = Honkai Impact 3
2 = Wuthering Waves